# Regression Test Matrix — Crypto Trader Pro

## Frontend polling
- [ ] Baseline round polling interval captured (3000 ms)
- [ ] Baseline user sync interval captured (6000 ms)
- [ ] Balance + my_bets calls remain paired and consistent
- [ ] Hidden-tab polling pauses and resumes cleanly
- [ ] No overlapping round/user sync
- [ ] Round end and betting close remain timely
- [ ] Result reveal triggers expected refresh
- [ ] Slow network / 429 / 5xx / offline recovery
- [ ] Notifications cadence and manual refresh remain correct

## Database migrations
- [ ] Empty database can migrate to expected schema
- [ ] Existing schema migration preserves all rows
- [ ] Re-running migrations is safe
- [ ] Interrupted migration can resume safely
- [ ] Constraints, indexes, defaults, triggers, functions verified
- [ ] Runtime endpoints no longer execute avoidable DDL
- [ ] Rollback/forward recovery documented

## Deposit scanner
- [ ] Starts at persisted last-successful block + 1
- [ ] Handles no-new-block case
- [ ] Handles chunk boundaries without gaps/overlap errors
- [ ] Handles RPC timeout and failed middle chunk
- [ ] Checkpoint does not pass failed range
- [ ] Restarts from persisted checkpoint
- [ ] Confirmation threshold enforced (default 3)
- [ ] Duplicate log / transaction cannot double-credit
- [ ] Token contract, destination, amount and decimals validated
- [ ] Below-minimum deposit rejected
- [ ] Reorg handling and rescan window verified
- [ ] Deposit ledger + wallet credit + checkpoint atomic

## Cron and settlement
- [ ] Missing/invalid CRON_SECRET returns 401
- [ ] Unsupported HTTP method returns 405
- [ ] Advisory lock serializes overlapping runs
- [ ] Multiple expired rounds settle correctly
- [ ] Retry does not duplicate result or payout
- [ ] Telegram failure does not corrupt settlement
- [ ] DB error rolls back incomplete state
- [ ] MAX_SETTLEMENT_ATTEMPTS boundary verified
- [ ] Execution duration below Vercel maxDuration

## End-to-end financial invariants
- [ ] Bet debit and bet insert are atomic
- [ ] Insufficient balance rejects bet
- [ ] Winning payout is correct and exactly once
- [ ] Losing bet is not paid
- [ ] Wallet balance reconciles with ledger
- [ ] Deposit credit occurs exactly once and only after confirmations
- [ ] No production secrets or real funds used in tests

## Release gates
- [ ] All syntax checks pass
- [ ] Unit tests pass
- [ ] Integration tests pass on disposable staging DB
- [ ] Before/after API request rate recorded
- [ ] Before/after cron duration recorded
- [ ] Before/after DB query timings recorded
- [ ] Before/after Vercel CPU measured over comparable windows
- [ ] Preview deployment manually verified
- [ ] Explicit production approval obtained
