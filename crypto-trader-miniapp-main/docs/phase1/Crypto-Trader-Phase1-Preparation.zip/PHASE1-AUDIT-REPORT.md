# Crypto Trader Pro — Phase 1 Baseline & Test Preparation

**Status:** Preparation only. No application source files were edited, no database was contacted, and nothing was deployed.

## Selected source of truth

The user selected the uploaded `crypto-trader-miniapp-main.zip` as the authoritative baseline. GitHub/current production source comparison is intentionally out of scope for this ZIP-only decision.

## Backup integrity

- Original upload: `crypto-trader-miniapp-main.zip`
- Preserved byte-for-byte copy: `crypto-trader-miniapp-main-baseline.zip`
- SHA-256: `30c00196d523ae076e8dcc96b9166fb0986a6ee42a57d16d7d4fa1a873857fbf`
- Original and preserved-copy SHA-256 match.
- ZIP integrity check: passed (`unzip -t`, no archive errors).
- Archive top-level directory: `crypto-trader-miniapp-main/`
- Archive entries: 31 (including directories)
- Extracted source inventory: 14 JavaScript files, 3 HTML files, plus assets/configuration/archive backup.
- Snapshot timestamps inside ZIP: 2026-10-28 18:49.
- ZIP does not contain `.git` metadata. A Git backup branch cannot be created from this ZIP alone; no repository was cloned or altered.

## Baseline source observations (read-only)

### Frontend polling — `index.html`

- `ROUND_POLL = 3000` ms and `USER_POLL = 6000` ms.
- `poll()` is scheduled every 1 second, but guarded by these elapsed-time checks and busy flags.
- Each `syncUser()` calls `balance` and `my_bets` concurrently; therefore the steady-state baseline is approximately 20 balance requests/minute and 20 my-bets requests/minute per continuously active authenticated client, plus up to 20 rounds requests/minute. Notifications are separately refreshed every 30 seconds.
- Round duration is 180 seconds and betting duration is 150 seconds in the frontend source.

### Runtime schema work

- `api/game.js`, `api/auth.js`, `api/admin.js`, `api/index.js`, and `api/cron.js` contain schema DDL statements (`CREATE TABLE`, `ALTER TABLE`, etc.).
- The exact call paths and ordering must be mapped before extracting migrations. Do not remove DDL until a schema inventory and migration equivalence checks exist.

### Deposit scanner — `api/cron.js`

- Reads the latest BSC block number, then scans from `max(0, latest - 100)` through `latest` in chunks of 5 blocks.
- This inclusive range is up to 101 blocks, normally 21 `eth_getLogs` chunk requests per invocation, plus the `eth_blockNumber` request.
- A 150 ms delay is applied after each chunk.
- Chunk errors are caught and logged while the loop continues. This is a key correctness risk to resolve before introducing a persistent checkpoint: a failed range must not be treated as successfully scanned.
- Confirmation requirement defaults to 3 and can be overridden by `BSC_MIN_CONFIRMATIONS`.

### Cron / settlement — `api/cron.js`

- Cron handler accepts GET and POST and requires `Authorization: Bearer <CRON_SECRET>`.
- It obtains a PostgreSQL transaction-scoped advisory lock using key `739184205`.
- `MAX_SETTLEMENT_ATTEMPTS = 20` and calls `public.settle_expired_round()` in a loop.
- Cron also contains schema checks/DDL for channel/prediction tables and `sent_at`.
- `vercel.json` sets `api/cron.js` maxDuration to 60 seconds.

### Existing project test setup

- `package.json` contains only the `dev` script (`node server.js`); no test, lint, or typecheck script is defined.
- Runtime dependencies include `pg`, `@neondatabase/serverless`, `ethers`, and `@vercel/blob`.

## Baseline checks performed

- `unzip -t`: PASS.
- `node --check` on all 14 `.js` files using Node v22.16.0: PASS.
- No application source file was edited during these checks.
- No live environment variables, Neon database, BSC RPC, Telegram API, cron-job.org job, or Vercel deployment was accessed.

## Approved implementation workstreams (not started)

1. Frontend polling optimization.
2. Database migration separation.
3. Incremental BSC deposit scanner.
4. Cron and settlement query optimization.

## Regression test preparation

### Test harness

Use Node's built-in `node:test` and `node:assert` to avoid adding a dependency initially. Keep all tests isolated from production secrets and production services. Add deterministic mocks for time, fetch/BSC JSON-RPC, Telegram requests, and PostgreSQL query boundaries. Integration tests must use a separate disposable staging database.

### Required suites and release gates

| Suite | Required cases | Release gate |
|---|---|---|
| Frontend polling | 3s/6s baseline capture; configured cadence; hidden-tab pause; busy guard; no duplicate overlapping requests; round-boundary refresh; slow/failing network retry | UI remains current; no missed betting lock/result; lower request count measured |
| Migrations | Empty schema; current schema; partial migration; rerun/idempotency; existing rows preserved; indexes/constraints/defaults match | Schema diff has no unintended drops/data rewrites; migration can safely resume |
| Deposit scanner | New block range; no-new-block case; inclusive boundaries; 3-confirmation default; configured confirmation count; failed middle chunk; RPC timeout; restart/resume; duplicate log; duplicate TX; wrong token/recipient; below-minimum amount; reorg/reorg-depth handling | No skipped block range; no duplicate or premature credit; credit + ledger + checkpoint atomic |
| Cron/settlement | missing/invalid secret; unsupported method; concurrent invocation; advisory lock; zero/one/multiple expired rounds; settlement retry; notification failure; DB rollback; max-attempt boundary | No duplicate result/payout; lock preserved; retry safe; execution fits configured duration |
| End-to-end game | authenticate; round fetch; bet placement; balance deduction; round close; result; payout; history refresh | Existing business rules and balances exactly preserved |

### Financial invariants

- A deposit transaction/log can credit at most once.
- A deposit is not credited before the configured confirmation threshold.
- A failed scan range is retried; checkpoint cannot advance beyond an unprocessed range.
- Bet debit and bet record remain atomic.
- Settlement and payout are idempotent under retries/concurrent cron invocations.
- Wallet ledger and displayed balance reconcile after every test.
- No production wallet, deposit, or payout data is used in tests.

## Before implementation

1. Create a separate working copy/branch from this exact baseline; do not edit the preserved ZIP or extracted baseline directory.
2. Capture a schema-only dump from a staging database and map every runtime DDL statement to the migration plan.
3. Record current API request rates, cron duration, DB query timings, and Vercel CPU using a controlled baseline window.
4. Implement one workstream at a time and run the relevant suite plus the full regression suite.
5. Deploy only to Preview/staging after tests; production deployment requires separate explicit approval.

## Important limitation

The ZIP provides source code, not a live database schema, production environment configuration, deployment commit, or cron-job.org execution history. Those must be separately supplied or inspected in a later, explicitly approved stage. This report does not claim live CPU causality or measured optimization gains.
