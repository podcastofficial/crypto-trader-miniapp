Crypto Trader Pro Phase 1 preparation bundle

- crypto-trader-miniapp-main-baseline.zip: byte-for-byte backup copy of the user's uploaded ZIP
- PHASE1-AUDIT-REPORT.md: baseline integrity, source observations, limitations, and implementation/test plan
- REGRESSION-TEST-MATRIX.md: checkbox test matrix for the four approved workstreams
- baseline-archive.sha256: archive SHA-256
- source-file-manifest.sha256: SHA-256 for every extracted source file

No project source code was modified. No production database, external RPC, cron-job.org job, or Vercel deployment was accessed.
